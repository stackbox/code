#!/usr/bin/env/bash
rm *.pyc
